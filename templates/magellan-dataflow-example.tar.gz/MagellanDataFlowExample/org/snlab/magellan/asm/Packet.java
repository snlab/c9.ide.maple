package org.snlab.magellan.asm;

public class Packet {

	String src;
	
	String dst;
	
	public Packet(String src, String dst){
		this.src = src;
		this.dst = dst;
	}
}
