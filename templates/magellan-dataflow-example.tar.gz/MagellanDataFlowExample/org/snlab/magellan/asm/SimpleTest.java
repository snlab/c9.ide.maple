package org.snlab.magellan.asm;

import java.util.HashMap;
import java.util.Map;

public class SimpleTest {
	
	Map<String, String> macTable = new HashMap<String, String>();
	
	public void setMacTable(){
		macTable.put("10.0.0.1", "sw1");
		macTable.put("10.0.0.2", "sw01");
		macTable.put("10.0.0.3", "sw001");
		macTable.put("10.0.0.4", "sw0001");
		macTable.put("10.0.0.5", "sw00001");
		macTable.put("10.0.0.6", "sw000001");
	}

	public int onPacket(Packet packet){
		String src = packet.src;
		String des = packet.dst;
		int swSrc = src.hashCode();
		int swDes = des.hashCode();
		int result = swSrc + swDes;
		return result;
	}
	
	public int onPacketCondition(Packet packet){
		String src = packet.src;
		String des = packet.dst;
		int swSrc = src.hashCode();
		int swDes = 0;
		des.hashCode();
		int result;
		if(swSrc > swDes){
			result = swSrc + swDes;
		}else{
			result = swSrc - swDes;
		}
		return result;
	}
	
	public int onPacketConditionNoElse(Packet packet){
		String src = packet.src;
		String des = packet.dst;
		int swSrc = src.hashCode();
		int swDes = 0;
		des.hashCode();
		int result = 0;
		if(swSrc > swDes){
			result = swSrc + swDes;
		}
		return result;
	}
	
	private String myRoute(String sw, String dw){
		return "route: " + sw + dw;
	}
	
	public String onPacketWithTable(Packet packet){
		String src = packet.src;
		String dst = packet.dst;
		String sw = macTable.get(src);
		String dw = macTable.get(dst);
		return myRoute(sw, dw);
	}
	
	public int onPacketWithTableExplorer(Packet packet){
		for(Map.Entry<String, String> entry1: macTable.entrySet()){
			String key1 = entry1.getKey();
			String value1 = entry1.getValue();
			for(Map.Entry<String, String> entry2: macTable.entrySet()){
				String key2 = entry2.getKey();
				String value2 = entry2.getValue();
				myRoute(value1, value2);
			}
		}
		return 1;
	}
	
	public int testMapLoop(Packet packet){
		for(Map.Entry<String, String> entry1: macTable.entrySet()){
			
		}
		String src = packet.src;
		String dst = packet.dst;
		String sw = macTable.get(src);
		String dw = macTable.get(dst);
		return 1;
	}
	
	Map<String, Integer> loopTable = new HashMap<String, Integer>();
	
	public int onPacketWithLoop(Packet packet){
		String src = packet.src;
		String des = packet.dst;
		int num = loopTable.get(src);
		int r = 0;
		for(int i=0; i<num; i++){
			//int k = 0;
			r += des.length();
		}
		//int j = num;
		//int m = k;
		return r;
	}
	
	public void testOut(){
		int out = 8;
		System.out.println(out);
	}
	
	public static void main(String[] args){
		SimpleTest st = new SimpleTest();
		st.setMacTable();
		Packet p = new Packet("10.0.0.1", "10.0.0.2");
		
		st.onPacketWithTable(p);
	}
}
