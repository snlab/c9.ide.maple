package org.snlab.magellan.asm;

public class LoopTest {
	
	public void test(){
		System.out.println("hello");
	}
	
	public void testLoop(){
		for(int i=0; i<3; i++){
			System.out.println("hello");
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		LoopTest lt = new LoopTest();
		lt.test();
	}

}
