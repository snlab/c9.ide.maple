package org.snlab.magellan.asm;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;

import org.objectweb.asm.ClassReader;
import org.objectweb.asm.ClassWriter;
import org.objectweb.asm.tree.AbstractInsnNode;
import org.objectweb.asm.tree.ClassNode;
import org.objectweb.asm.tree.FrameNode;
import org.objectweb.asm.tree.IincInsnNode;
import org.objectweb.asm.tree.InsnList;
import org.objectweb.asm.tree.InsnNode;
import org.objectweb.asm.tree.JumpInsnNode;
import org.objectweb.asm.tree.LabelNode;
import org.objectweb.asm.tree.MethodNode;
import org.objectweb.asm.tree.VarInsnNode;

import static org.objectweb.asm.Opcodes.*;

public class TestLoopASM {

	public static void main(String[] args) throws IOException{

		FileInputStream input = new FileInputStream("/Users/tony/Documents/workspace/dataflow/src/main/java/org/snlab/magellan/asm/LoopTest.class");
		
		ClassNode cn = new ClassNode();
		ClassReader cr = new ClassReader(input);
		cr.accept(cn, 0);
		
		List<MethodNode> methods = (List<MethodNode>)cn.methods;
		for(MethodNode method: methods){
			if(method.name.equals("test")){
				InsnList insnList = method.instructions;
				
				InsnList newInsnList = new InsnList();
				
				InsnList removeReturnInsnList = new InsnList();
				
                Iterator ite = insnList.iterator();
				
				while(ite.hasNext()){
					AbstractInsnNode insn=(AbstractInsnNode)ite.next();
					if(insn instanceof InsnNode){
						InsnNode insnNode = (InsnNode)insn;
						if(insnNode.getOpcode() == RETURN){
							continue;
						}
					}
					removeReturnInsnList.add(insn);
				}
				
				newInsnList.add(new InsnNode(ICONST_0));
				newInsnList.add(new VarInsnNode(ISTORE, 3));
				LabelNode start = new LabelNode();
				newInsnList.add(start);
				newInsnList.add(new VarInsnNode(ILOAD, 3));
				newInsnList.add(new InsnNode(ICONST_3));
				LabelNode end = new LabelNode();
				newInsnList.add(new JumpInsnNode(IF_ICMPGE, end));
				newInsnList.add(removeReturnInsnList);
				newInsnList.add(new IincInsnNode(3, 1));
				newInsnList.add(new JumpInsnNode(GOTO, start));
				newInsnList.add(end);
				newInsnList.add(new InsnNode(RETURN));
				
				method.instructions = newInsnList;
				

				InsnList lastInsns = new InsnList();
				lastInsns.add(method.instructions);
				method.instructions = lastInsns;//////
				
			}
		}
		
		ClassWriter cw = new ClassWriter(ClassWriter.COMPUTE_FRAMES);
		cn.accept(cw);
		
		byte[] bytecodes = cw.toByteArray();
		FileOutputStream output = new FileOutputStream("/Users/tony/Documents/workspace/dataflow/src/main/java/org/snlab/magellan/asm/LoopTestNew.class");
		output.write(bytecodes);
		output.flush();
		output.close();
	}
}
