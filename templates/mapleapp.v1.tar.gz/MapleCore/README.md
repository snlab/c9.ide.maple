#Maple Controller

- [Maple Primer](#maple-primer)
- [Walkthrough](#walkthrough)
  - [Installation](#installation)
  - [Run Maple](#run-maple)
- [Demo](#demo)
  - [Online Streaming](#online-streaming)
- [Write Your AP](#write-your-ap)
  - [Sample AP application](#sample-ap-application)
  - [AP APIs](#ap-apis)
- [Contact](#contact)

##Maple Primer

[Algorithmic Policy
(AP)](http://conferences.sigcomm.org/sigcomm/2013/papers/sigcomm/p87.pdf)
is a SDN programming model which allows programs written in ordinary programming
language to be transparently deployed onto high-performance switching hardware
through a dynamic translation of the program into the OpenFlow switch
abstraction.

[Maple Controller](http://www.Maple-website.org) is composed of three major modules:

  * **MapleCore** provides the AP programming model as well as a tracing runtime and trace tree compiler. MapleCore is controller-agnostic and can be applied to multiple controller platforms. E.g. OpenDaylight and ONOS.
  * **odlmaple** provides the implementation of the MapleCore southbound API for OpenDaylight.
  * **MapleGUI** provides a browser-based GUI to visualize the network and internal state of Maple Controller.  

[OpenDaylight (ODL)](http://www.opendaylight.org) has emerged as one of the
leading Software-Defined Network controllers. The goal of OpenDaylight is to
promote and accelerate a community-led and industry-supported open source
framework. OpenDaylight is supported by a number of vendors, including Brocade, 
Cisco, Citrix, Dell, HP, IBM, Intel, …). OpenDaylight supports a variety of applications
including applications for network virtualization and cloud (OpenStack). 

[Maple @ OpenDaylight](http://www.Maple-website.org). 
We provide `odlmaple`, which allows Maple to run on top of OpenDaylight and enables
Algorithmic Policy based SDN programming in OpenDaylight. 
Maple@ODL currently supports AP programming in
Java. Support for Python is planned for the near future. 

##Walkthrough

###Installation

1. Download three modules

        git clone https://github.com/snlab/MapleCore.git 
        git clone https://github.com/snlab/odlmaple.git
        git clone https://github.com/snlab/MapleGUI.git
    
2. Build MapleCore and odlmaple:

    Install prerequisite: JDK 1.7+ and Maven 3+.
    Please note the build machine must be connected to Internet because Maven needs to retrieve the build tools from remote repositories.

        cd MapleCore
        mvn clean install
        ...
        cd ../odlmaple
        mvn clean install
    
3. Build MapleGUI

    Install prerequisite: nodejs and npm.

        sudo apt-get install npm nodejs nodejs-legacy (for Ubuntu 14.04 and later version)
        or
        sudo yum install nodejs npm

    After nodejs has been installed, use npm to install bower:

        sudo npm install -g bower
        cd MapleGUI
        make local

###Run Maple

1. In SSH session, start Apache Karaf container for ODL:

        cd odlmaple/
        ./karaf/target/assembly/bin/karaf

    You will see "Maple Starts" in the ODL console when Maple is running.
    
2. start Mininet:

        sudo mn --controller=remote,ip=<IP address of the server running Maple> --mac --topo=tree,depth=1,fanout=5
    
3. In Mininet, check the flow tables and ping hosts:

        sh ovs-ofctl dump-flows s1
        ...
        h1 ping h2
        sh ovs-ofctl dump-flows s1
        ...
        pingall
        ...
        sh ovs-ofctl dump-flows s1

4. Check the network through GUI:

        cd MapleGUI/dist
        node server.js

    Make sure ODLMaple is running (you see "Maple starts" in the ODL console), and install the odl-restconf feature.  
    Now open up a browser and go to http://{controller-ip-address}:3000 to view the web UI. 

##Demo

###Online Streaming

With Maple, programmers focus on **what** they want a network to behave, without needing to specify **how** to achieve that correctly and efficiently in the network.

In this demo, we show how Maple can choice the shortest path for streaming connections and can automatically reroute the connections when something bad happens in network (e.g., link down), without any input from users.

1. Download Demo scripts:

        git clone https://github.com/snlab/MapleDemo.git

2. Simulate a network with loop:

        cd MapleDemo/onlineStreaming
        sudo mn --custom ./topo3switches.py --topo mytopo --controller=remote,ip=<IP address of the server running Maple> --mac

3. Start streaming server on host 1, and one client on host 2:

        (In mininet console)
        h2 ./server-http.sh </path/to/a video file> &
        h3 ./clients-http.sh &

4. Check how Maple choice the shortest path for streaming connections:

        (In mininet console) sh ovs-ofctl dump-flows s1
        (In Maple GUI) Check tabs topology and flow-tables

5. Simulate a link failure:

        (In mininet console) link s1 s2 down

6. Check how Maple do a user-oblivious reroute: 

        (Video continues in the client)
        (In Maple GUI) Check tabs topology and flow-tables. The connection has been rerouted to bypasses link s1 <-> s2.
        

##Write Your APs

Specification of Maple programming language is coming soon. This README file gives a brief overview of writing APs with Maple.

###Sample AP application

An sample application, which routes IPv4 packets along shortest path, unless the source host is in the black list. All programmers need to do is to specify "What to do when packets of new flows are received." The complete source code of the application can be found at MapleCore/src/main/java/org/maple/core/RoutingApp1.java

    
    public class RoutingApp1 extends MapleApp{
	    
	    Set<Integer> blackList;
	    
	    public RoutingApp1(){ 
		    blackList = new HashSet<Integer>();
		    
		    blackList.add(IPv4.toIPv4Address("10.0.0.1"));
		    blackList.add(IPv4.toIPv4Address("10.0.0.7"));
	    }
	
		@Override
	    Action onPacket(MaplePacket pkt) {
		    if(pkt.ethType() == Ethernet.TYPE_IPv4){
			    
			    if(blackList.contains(pkt.IPv4Src())) {
				    return Drop();
			    }
			    else {
				    return ShortestPath(myTopo, pkt);
				}
		    }
		    else {
			    return passToSystem(pkt);
		    }
	    }
    }

###AP APIs

Currently, Maple supports the following APIs which can be used by AP applications.

  * **readData** returns the running status of the network. For example, readData("/root/network-topology/topology") returns the snapshot of the network topology. 
  * **ingressPort** returns the switch port where the packet is received.
  * **ethSrc**, **ethDst** returns the source MAC address and destination MAC address, respectively.
  * **ethType** returns the Ethernet type.
  * **ingressPortIs** 
  * **ethSrcIs**, **ethDstIs**
  * **ethTypeIs**
  
##Contact

Maple project is led by Professor Y. Richard Yang at Yale University.
You can contact us through maple-design@googlegroups.com.
