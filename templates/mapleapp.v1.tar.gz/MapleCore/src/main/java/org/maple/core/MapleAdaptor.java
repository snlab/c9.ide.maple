/*
 * Copyright (c) 2016 SNLAB and others.  All rights reserved.
 *
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Public License v1.0 which accompanies this distribution,
 * and is available at http://www.eclipse.org/legal/epl-v10.html
 */
package org.maple.core;

import org.maple.core.tracetree.*;
import org.opendaylight.yang.gen.v1.urn.opendaylight.inventory.rev130819.NodeConnectorRef;
import org.opendaylight.yang.gen.v1.urn.tbd.params.xml.ns.yang.network.topology.rev131021.TpId;

import java.util.List;

public class MapleAdaptor implements MapleDataPathAdaptor, MapleDataStoreAdaptor {

  private MapleCore mapleCore;

  public void setMapleCore(MapleCore mapleCore) {
    this.mapleCore = mapleCore;
  }

  public void sendPacket(byte[] payload, NodeConnectorRef ingress, Action action) {

  }

  public void installPath(Action action, Match match, Integer priority) {

  }

  public void deletePath(Action action, Match match, Integer priority) {

  }

  public void installRule(Rule r, NodeConnectorRef sw) {

  }

  public void deleteRule(Rule r, NodeConnectorRef sw) {

  }

  public Object readData(String xpath) {
    return null;
  }

  public void writeData(String xpath, Object data) {} //TODO

  public void writeTraceTree(TraceTree tt) {

  }
}
