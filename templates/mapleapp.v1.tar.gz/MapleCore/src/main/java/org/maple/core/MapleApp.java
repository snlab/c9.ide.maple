/*
 * Copyright (c) 2016 SNLAB and others.  All rights reserved.
 *
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Public License v1.0 which accompanies this distribution,
 * and is available at http://www.eclipse.org/legal/epl-v10.html
 */
package org.maple.core;

import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;

import org.maple.core.packet.ARP;
import org.maple.core.packet.Ethernet;
import org.maple.core.tracetree.Action;
import org.maple.core.tracetree.MaplePacket;
import org.opendaylight.yang.gen.v1.urn.opendaylight.inventory.rev130819.NodeConnectorRef;
import org.opendaylight.yang.gen.v1.urn.opendaylight.inventory.rev130819.NodeRef;
import org.opendaylight.yang.gen.v1.urn.opendaylight.inventory.rev130819.nodes.Node;
import org.opendaylight.yang.gen.v1.urn.opendaylight.inventory.rev130819.nodes.NodeKey;
import org.opendaylight.yang.gen.v1.urn.tbd.params.xml.ns.yang.network.topology.rev131021.network.topology.Topology;

public abstract class MapleApp {
    private MapleCore mapleCore;
    private static HashMap<String, Set<String>> alreadySendForARP;
    private Date lastSeenArp;
	private HashMap<Long, NodeConnectorRef> mac2NCR;

    MapleApp() {
        mapleCore = MapleCore.allocateMapleCore();
        mapleCore.setMapleApp( this );

        alreadySendForARP = new HashMap<String, Set<String>>();
        lastSeenArp = new Date();
		mac2NCR = new HashMap<Long, NodeConnectorRef>();
    }

    Object readData(String xpath) {
        return mapleCore.readData(xpath);
    }

    void writeData(String xpath, Object data) {
        mapleCore.writeData(xpath, data);
    }

    public Action passToSystem(MaplePacket pkt){
    	if (pkt.ethType() == Ethernet.TYPE_ARP) {
			//ARP pARP = (ARP) pkt.frame.getPayload();
			//tring targetIpStirng =  pARP.getTargetProtocolAddress().toString();

		    Date currentDate = new Date();
			if(currentDate.getTime() - lastSeenArp.getTime() > 5000){ //Maximum speed of sending ARP packet is 1/s
				System.out.println("the list is clear");
				alreadySendForARP.clear();
				lastSeenArp = new Date();
			}

			System.out.println("arp received");
			NodeConnectorRef ingress;
			long srcMac = pkt.ethSrc();
			long dsyMac = pkt.ethDst();
			ingress = pkt.ingressPort();

			String node = ingress.getValue().firstIdentifierOf(Node.class)
					.firstKeyOf(Node.class, NodeKey.class).getId().getValue();

			if(!this.mac2NCR.containsKey(srcMac)){
			    this.mac2NCR.put(srcMac, ingress);//ingress
			}

			String srcMacString = String.valueOf(srcMac);
			String dstMacString = String.valueOf(dsyMac);
			String key = srcMacString + " " + dstMacString;

			if(alreadySendForARP.containsKey(key)){
				if(alreadySendForARP.get(key).contains(node)) {//ingress
					System.out.println("arp dropped");
					return Action.Drop();
				} else {
					alreadySendForARP.get(key).add(node);
				}
			}else{
				Set<String> tempSet = new HashSet<String>();
				tempSet.add(node);//ingress
				alreadySendForARP.put(key, tempSet);
			}
			System.out.println("get arp:" + srcMacString + "at: " + node);
			return Action.Flood();
		}else{
			return null;
		}
    }

    public Action ShortestPath(Topology topo, MaplePacket pkt){
    	ShortestPath stp = new ShortestPath( );

		if(topo==null){
		    topo = (Topology) readData("/root/network-topology/topology");
		}

    	return stp.singleShortestPath(topo, pkt, mac2NCR);
    }

    public Action Drop() {
    	return Action.Drop();
    }

    abstract void onDataChanged(Object data);

    abstract Action onPacket(MaplePacket pkt);
}
