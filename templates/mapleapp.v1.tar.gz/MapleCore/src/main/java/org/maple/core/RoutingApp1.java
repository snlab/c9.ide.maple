/*
 * Copyright (c) 2016 SNLAB and others.  All rights reserved.
 *
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Public License v1.0 which accompanies this distribution,
 * and is available at http://www.eclipse.org/legal/epl-v10.html
 */
package org.maple.core;

import java.util.HashSet;
import java.util.Set;

import org.maple.core.packet.Ethernet;
import org.maple.core.packet.IPv4;
import org.maple.core.tracetree.Action;
import org.maple.core.tracetree.MaplePacket;
import org.opendaylight.yang.gen.v1.urn.tbd.params.xml.ns.yang.network.topology.rev131021.network.topology.Topology;

public class RoutingApp1 extends MapleApp{
	Topology myTopo;
	Set<Integer> blackList;

	public RoutingApp1(){
		blackList = new HashSet<Integer>();

		blackList.add(IPv4.toIPv4Address("10.0.0.1"));
		blackList.add(IPv4.toIPv4Address("10.0.0.7"));
	}

	@Override
	void onDataChanged(Object data) {
		if(data instanceof Topology){
		    myTopo = (Topology)data;
		}
	}

	@Override
	Action onPacket(MaplePacket pkt) {
		if(pkt.ethType() == Ethernet.TYPE_IPv4){

			if(blackList.contains(pkt.IPv4Src())) {
				return Drop();
			}
			else
				return ShortestPath(myTopo, pkt);

		}else{

			return passToSystem(pkt);

		}
	}
}
