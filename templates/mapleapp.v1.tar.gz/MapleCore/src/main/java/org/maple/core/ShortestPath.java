/*
 * Copyright (c) 2016 SNLAB and others.  All rights reserved.
 *
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Public License v1.0 which accompanies this distribution,
 * and is available at http://www.eclipse.org/legal/epl-v10.html
 */
package org.maple.core;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.maple.core.tracetree.Action;
import org.maple.core.tracetree.MaplePacket;
import org.opendaylight.maple.impl.alg.NetworkGraphImpl;
import org.opendaylight.maple.impl.alg.NetworkGraphService;
import org.opendaylight.yang.gen.v1.urn.opendaylight.inventory.rev130819.NodeConnectorId;
import org.opendaylight.yang.gen.v1.urn.opendaylight.inventory.rev130819.NodeConnectorRef;
import org.opendaylight.yang.gen.v1.urn.opendaylight.inventory.rev130819.NodeId;
import org.opendaylight.yang.gen.v1.urn.opendaylight.inventory.rev130819.Nodes;
import org.opendaylight.yang.gen.v1.urn.opendaylight.inventory.rev130819.node.NodeConnector;
import org.opendaylight.yang.gen.v1.urn.opendaylight.inventory.rev130819.node.NodeConnectorKey;
import org.opendaylight.yang.gen.v1.urn.opendaylight.inventory.rev130819.nodes.Node;
import org.opendaylight.yang.gen.v1.urn.opendaylight.inventory.rev130819.nodes.NodeKey;
import org.opendaylight.yang.gen.v1.urn.tbd.params.xml.ns.yang.network.topology.rev131021.TpId;
import org.opendaylight.yang.gen.v1.urn.tbd.params.xml.ns.yang.network.topology.rev131021.network.topology.topology.Link;
import org.opendaylight.yang.gen.v1.urn.tbd.params.xml.ns.yang.network.topology.rev131021.network.topology.Topology;
import org.opendaylight.yangtools.yang.binding.InstanceIdentifier;

public class ShortestPath {

	static NetworkGraphService ngs;

	public ShortestPath() {
		ngs = new NetworkGraphImpl();
	}

	private TpId getTpIdFromNodeConnectorRef(NodeConnectorRef ncf){
		NodeConnectorId nci = ncf.getValue()
	            .firstKeyOf(NodeConnector.class, NodeConnectorKey.class)
	            .getId();
		return new TpId(nci);
	}

    private void displayLinks(List<Link> links){
    	System.out.println("links in maple app");
		for(int i=0; i<links.size(); i++){
			System.out.println(i+"srcNodeId:"+links.get(i).getSource().getSourceNode().getValue());
			System.out.println(i+"dstNodeId:"+links.get(i).getDestination().getDestNode().getValue());
		}
	}

    public Action singleShortestPath(Topology topo, MaplePacket pkt, HashMap<Long, NodeConnectorRef> mac2NCR){

		Long srcMac = pkt.ethSrc();
		Long dstMac = pkt.ethDst();

		List<Link> links = topo.getLink();
		//displayLinks(links);
		ngs.clear();
		ngs.addLinks(links);

		//displayLinks(ngs.getAllLinks());

		NodeConnectorRef srcNCR = mac2NCR.get(srcMac);
		NodeConnectorRef dstNCR = mac2NCR.get(dstMac);

		if (srcNCR == null || dstNCR == null)
			return null;

		String srcNodeIdString = srcNCR.getValue().firstIdentifierOf(Node.class)
				.firstKeyOf(Node.class, NodeKey.class).getId().getValue();
		String dstNodeIdString = dstNCR.getValue().firstIdentifierOf(Node.class)
				.firstKeyOf(Node.class, NodeKey.class).getId().getValue();

		NodeId srcNodeId = new NodeId(srcNodeIdString);
		NodeId dstNodeId = new NodeId(dstNodeIdString);

		if(srcNodeId.getValue().equals(dstNodeId.getValue())){
			Action action = Action.Route(new ArrayList<Link>(), dstNCR);
			return action;
		}

		org.opendaylight.yang.gen.v1.urn.tbd.params.xml.ns.yang
		    .network.topology.rev131021.NodeId srcNodeIdForTBD = new org.opendaylight.yang.gen.v1.urn.tbd.params.xml.ns.yang
		    .network.topology.rev131021.NodeId(
				srcNodeId);

		org.opendaylight.yang.gen.v1.urn.tbd.params.xml.ns.yang
	        .network.topology.rev131021.NodeId dstNodeIdForTBD = new org.opendaylight.yang.gen.v1.urn.tbd.params.xml.ns.yang
	        .network.topology.rev131021.NodeId(
			    dstNodeId);
		List<Link> path;
		try{
		    path = ngs.getPath(srcNodeIdForTBD, dstNodeIdForTBD);
		}catch(Exception e){
			return null;
		}

		List<TpId> tpIdList = new ArrayList<TpId>();
		for(Link link: path){
			//if(link.getSource().getSourceNode().getValue().equals(srcNodeIdString)){
			//	System.out.println("get sendOutNCR");
			//	sendOutNCR = getNodeConnectorRefFromTpId(link.getSource().getSourceTp());
			//}
			TpId srcIpId = link.getSource().getSourceTp();
			tpIdList.add(srcIpId);
		}
		tpIdList.add(getTpIdFromNodeConnectorRef(dstNCR));

		Action action = Action.Route(path, dstNCR);
		return action;
	}
}
