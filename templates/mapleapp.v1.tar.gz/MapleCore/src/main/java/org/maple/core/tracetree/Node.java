/*
 * Copyright (c) 2016 SNLAB and others.  All rights reserved.
 *
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Public License v1.0 which accompanies this distribution,
 * and is available at http://www.eclipse.org/legal/epl-v10.html
 */
package org.maple.core.tracetree;

import java.util.List;
import org.maple.core.packet.Ethernet;
import org.opendaylight.yang.gen.v1.urn.tbd.params.xml.ns.yang.network.topology.rev131021.TpId;

public abstract class Node {
  public Node father;

  public abstract void delete(Node node);

  public void invalidate() {
    father.delete( this );
  }
  public abstract void augment(List<TraceItem> trace, Action action);
}
